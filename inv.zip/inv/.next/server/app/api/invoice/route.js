/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/invoice/route";
exports.ids = ["app/api/invoice/route"];
exports.modules = {

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Finvoice%2Froute&page=%2Fapi%2Finvoice%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Finvoice%2Froute.ts&appDir=%2Fhome%2Fgopi%2FDocuments%2FProjects%2Finvoice%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fgopi%2FDocuments%2FProjects%2Finvoice&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Finvoice%2Froute&page=%2Fapi%2Finvoice%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Finvoice%2Froute.ts&appDir=%2Fhome%2Fgopi%2FDocuments%2FProjects%2Finvoice%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fgopi%2FDocuments%2FProjects%2Finvoice&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _home_gopi_Documents_Projects_invoice_src_app_api_invoice_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/invoice/route.ts */ \"(rsc)/./src/app/api/invoice/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/invoice/route\",\n        pathname: \"/api/invoice\",\n        filename: \"route\",\n        bundlePath: \"app/api/invoice/route\"\n    },\n    resolvedPagePath: \"/home/gopi/Documents/Projects/invoice/src/app/api/invoice/route.ts\",\n    nextConfigOutput,\n    userland: _home_gopi_Documents_Projects_invoice_src_app_api_invoice_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZpbnZvaWNlJTJGcm91dGUmcGFnZT0lMkZhcGklMkZpbnZvaWNlJTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGaW52b2ljZSUyRnJvdXRlLnRzJmFwcERpcj0lMkZob21lJTJGZ29waSUyRkRvY3VtZW50cyUyRlByb2plY3RzJTJGaW52b2ljZSUyRnNyYyUyRmFwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9JTJGaG9tZSUyRmdvcGklMkZEb2N1bWVudHMlMkZQcm9qZWN0cyUyRmludm9pY2UmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQStGO0FBQ3ZDO0FBQ3FCO0FBQ2tCO0FBQy9GO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5R0FBbUI7QUFDM0M7QUFDQSxjQUFjLGtFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsc0RBQXNEO0FBQzlEO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQzBGOztBQUUxRiIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCIvaG9tZS9nb3BpL0RvY3VtZW50cy9Qcm9qZWN0cy9pbnZvaWNlL3NyYy9hcHAvYXBpL2ludm9pY2Uvcm91dGUudHNcIjtcbi8vIFdlIGluamVjdCB0aGUgbmV4dENvbmZpZ091dHB1dCBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgbmV4dENvbmZpZ091dHB1dCA9IFwiXCJcbmNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IEFwcFJvdXRlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9ST1VURSxcbiAgICAgICAgcGFnZTogXCIvYXBpL2ludm9pY2Uvcm91dGVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9pbnZvaWNlXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcInJvdXRlXCIsXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiYXBwL2FwaS9pbnZvaWNlL3JvdXRlXCJcbiAgICB9LFxuICAgIHJlc29sdmVkUGFnZVBhdGg6IFwiL2hvbWUvZ29waS9Eb2N1bWVudHMvUHJvamVjdHMvaW52b2ljZS9zcmMvYXBwL2FwaS9pbnZvaWNlL3JvdXRlLnRzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgd29ya0FzeW5jU3RvcmFnZSwgd29ya1VuaXRBc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgd29ya0FzeW5jU3RvcmFnZSxcbiAgICAgICAgd29ya1VuaXRBc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Finvoice%2Froute&page=%2Fapi%2Finvoice%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Finvoice%2Froute.ts&appDir=%2Fhome%2Fgopi%2FDocuments%2FProjects%2Finvoice%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fgopi%2FDocuments%2FProjects%2Finvoice&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./src/app/api/invoice/route.ts":
/*!**************************************!*\
  !*** ./src/app/api/invoice/route.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET),\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\nconst data = [\n    {\n        clientName: \"Client 1\",\n        description: \"Description 1\",\n        quantity: 2,\n        unitPrice: 10,\n        createdAt: new Date()\n    },\n    {\n        clientName: \"Client 2\",\n        description: \"Description 2\",\n        quantity: 3,\n        unitPrice: 15,\n        createdAt: new Date()\n    },\n    {\n        clientName: \"Client 3\",\n        description: \"Description 3\",\n        quantity: 1,\n        unitPrice: 8,\n        createdAt: new Date()\n    }\n];\nasync function GET() {\n    return Response.json({\n        success: true,\n        message: \"Success\",\n        data\n    }, {\n        status: 200\n    });\n}\nasync function POST(req) {\n    const { clientName, description, quantity, unitPrice } = await req.json();\n    if (!clientName || !description || !quantity || !unitPrice) {\n        return Response.json({\n            success: false,\n            message: \"Missing required fields\"\n        }, {\n            status: 400\n        });\n    }\n    data.push({\n        clientName,\n        description,\n        quantity,\n        unitPrice,\n        createdAt: new Date()\n    });\n    return Response.json({\n        success: true,\n        message: \"Success\",\n        data\n    }, {\n        status: 200\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9pbnZvaWNlL3JvdXRlLnRzIiwibWFwcGluZ3MiOiI7Ozs7O0FBUUEsTUFBTUEsT0FBZ0I7SUFDcEI7UUFDRUMsWUFBWTtRQUNaQyxhQUFhO1FBQ2JDLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxXQUFXLElBQUlDO0lBQ2pCO0lBQ0E7UUFDRUwsWUFBWTtRQUNaQyxhQUFhO1FBQ2JDLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxXQUFXLElBQUlDO0lBQ2pCO0lBQ0E7UUFDRUwsWUFBWTtRQUNaQyxhQUFhO1FBQ2JDLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxXQUFXLElBQUlDO0lBQ2pCO0NBQ0Q7QUFFTSxlQUFlQztJQUNwQixPQUFPQyxTQUFTQyxJQUFJLENBQ2xCO1FBQ0VDLFNBQVM7UUFDVEMsU0FBUztRQUNUWDtJQUNGLEdBQ0E7UUFDRVksUUFBUTtJQUNWO0FBRUo7QUFFTyxlQUFlQyxLQUFLQyxHQUFZO0lBQ3JDLE1BQU0sRUFBRWIsVUFBVSxFQUFFQyxXQUFXLEVBQUVDLFFBQVEsRUFBRUMsU0FBUyxFQUFFLEdBQUcsTUFBTVUsSUFBSUwsSUFBSTtJQUV2RSxJQUFJLENBQUNSLGNBQWMsQ0FBQ0MsZUFBZSxDQUFDQyxZQUFZLENBQUNDLFdBQVc7UUFDMUQsT0FBT0ksU0FBU0MsSUFBSSxDQUNsQjtZQUNFQyxTQUFTO1lBQ1RDLFNBQVM7UUFDWCxHQUNBO1lBQ0VDLFFBQVE7UUFDVjtJQUVKO0lBRUFaLEtBQUtlLElBQUksQ0FBQztRQUNSZDtRQUNBQztRQUNBQztRQUNBQztRQUNBQyxXQUFXLElBQUlDO0lBQ2pCO0lBRUEsT0FBT0UsU0FBU0MsSUFBSSxDQUNsQjtRQUNFQyxTQUFTO1FBQ1RDLFNBQVM7UUFDVFg7SUFDRixHQUNBO1FBQ0VZLFFBQVE7SUFDVjtBQUVKIiwic291cmNlcyI6WyIvaG9tZS9nb3BpL0RvY3VtZW50cy9Qcm9qZWN0cy9pbnZvaWNlL3NyYy9hcHAvYXBpL2ludm9pY2Uvcm91dGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHR5cGUgVERhdGEgPSB7XG4gIGNsaWVudE5hbWU6IHN0cmluZztcbiAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgcXVhbnRpdHk6IG51bWJlcjtcbiAgdW5pdFByaWNlOiBudW1iZXI7XG4gIGNyZWF0ZWRBdDogRGF0ZTtcbn07XG5cbmNvbnN0IGRhdGE6IFREYXRhW10gPSBbXG4gIHtcbiAgICBjbGllbnROYW1lOiBcIkNsaWVudCAxXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRGVzY3JpcHRpb24gMVwiLFxuICAgIHF1YW50aXR5OiAyLFxuICAgIHVuaXRQcmljZTogMTAsXG4gICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICB9LFxuICB7XG4gICAgY2xpZW50TmFtZTogXCJDbGllbnQgMlwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkRlc2NyaXB0aW9uIDJcIixcbiAgICBxdWFudGl0eTogMyxcbiAgICB1bml0UHJpY2U6IDE1LFxuICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgfSxcbiAge1xuICAgIGNsaWVudE5hbWU6IFwiQ2xpZW50IDNcIixcbiAgICBkZXNjcmlwdGlvbjogXCJEZXNjcmlwdGlvbiAzXCIsXG4gICAgcXVhbnRpdHk6IDEsXG4gICAgdW5pdFByaWNlOiA4LFxuICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgfSxcbl07XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBHRVQoKSB7XG4gIHJldHVybiBSZXNwb25zZS5qc29uKFxuICAgIHtcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICBtZXNzYWdlOiBcIlN1Y2Nlc3NcIixcbiAgICAgIGRhdGEsXG4gICAgfSxcbiAgICB7XG4gICAgICBzdGF0dXM6IDIwMCxcbiAgICB9XG4gICk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQT1NUKHJlcTogUmVxdWVzdCkge1xuICBjb25zdCB7IGNsaWVudE5hbWUsIGRlc2NyaXB0aW9uLCBxdWFudGl0eSwgdW5pdFByaWNlIH0gPSBhd2FpdCByZXEuanNvbigpO1xuXG4gIGlmICghY2xpZW50TmFtZSB8fCAhZGVzY3JpcHRpb24gfHwgIXF1YW50aXR5IHx8ICF1bml0UHJpY2UpIHtcbiAgICByZXR1cm4gUmVzcG9uc2UuanNvbihcbiAgICAgIHtcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIG1lc3NhZ2U6IFwiTWlzc2luZyByZXF1aXJlZCBmaWVsZHNcIixcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHN0YXR1czogNDAwLFxuICAgICAgfVxuICAgICk7XG4gIH1cblxuICBkYXRhLnB1c2goe1xuICAgIGNsaWVudE5hbWUsXG4gICAgZGVzY3JpcHRpb24sXG4gICAgcXVhbnRpdHksXG4gICAgdW5pdFByaWNlLFxuICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgfSk7XG5cbiAgcmV0dXJuIFJlc3BvbnNlLmpzb24oXG4gICAge1xuICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgIG1lc3NhZ2U6IFwiU3VjY2Vzc1wiLFxuICAgICAgZGF0YSxcbiAgICB9LFxuICAgIHtcbiAgICAgIHN0YXR1czogMjAwLFxuICAgIH1cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJkYXRhIiwiY2xpZW50TmFtZSIsImRlc2NyaXB0aW9uIiwicXVhbnRpdHkiLCJ1bml0UHJpY2UiLCJjcmVhdGVkQXQiLCJEYXRlIiwiR0VUIiwiUmVzcG9uc2UiLCJqc29uIiwic3VjY2VzcyIsIm1lc3NhZ2UiLCJzdGF0dXMiLCJQT1NUIiwicmVxIiwicHVzaCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/invoice/route.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Finvoice%2Froute&page=%2Fapi%2Finvoice%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Finvoice%2Froute.ts&appDir=%2Fhome%2Fgopi%2FDocuments%2FProjects%2Finvoice%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fgopi%2FDocuments%2FProjects%2Finvoice&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();